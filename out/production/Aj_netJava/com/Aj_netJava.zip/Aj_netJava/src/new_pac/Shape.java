package new_pac;

public abstract class Shape {
    public abstract double area();
}
