package com.School;

public class res {

}
