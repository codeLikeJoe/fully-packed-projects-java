package com.QThreeID;

enum IteCat {
    WOMEN,
    MEN,
    GIRLS,
    BOYS,
    BABIES
}
