package com.School;

import java.util.Scanner;

public class resultCalculator {
    public static void main(String[] args) {

    }
}
