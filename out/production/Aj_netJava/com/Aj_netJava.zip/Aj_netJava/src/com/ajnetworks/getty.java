package com.ajnetworks;

public class getty {
}
